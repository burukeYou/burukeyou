create
    definer = root@localhost procedure sp_exec_sql(IN tmp_sql text)
begin
  SET @tmpsql = tmp_sql;
  PREPARE stmt1 FROM @tmpsql;
  EXECUTE stmt1;
  DEALLOCATE PREPARE stmt1;
end;

