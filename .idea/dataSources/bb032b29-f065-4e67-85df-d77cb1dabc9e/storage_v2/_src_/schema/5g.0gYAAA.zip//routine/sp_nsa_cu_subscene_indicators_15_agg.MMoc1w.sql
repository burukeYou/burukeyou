create
    definer = root@`%` procedure sp_nsa_cu_subscene_indicators_15_agg(IN quarter_now datetime)
BEGIN
         drop table IF EXISTS nsa_cu_subscene_indicators_15;
         create table nsa_cu_subscene_indicators_15 as 
         SELECT  quarter_now as starttime,nr.scene_name,nr.subscene_name,
         sum(ce.pdcp_down_business_byte_count) ,SUM(ce.pdcp_up_business_byte_count)
         FROM cell_15_nsa_cu_indicator ce INNER JOIN dim_cfg_manual_subscene_cell_nr nr  on ce.cgi = nr.cgi
         GROUP BY nr.scene_name,nr.subscene_name;
    END;

