create
    definer = root@`%` procedure sp_nsa_entran_subscene_indicators_15_agg(IN quarter_now datetime)
BEGIN
         drop table IF EXISTS nsa_entran_subscene_indicators_15;
         create table nsa_entran_subscene_indicators_15 as 
         SELECT  quarter_now as starttime,lte.scene,lte.subscene,
            sum(sn_add_success_rate) as sn_add_success_rate,
            sum(sn_abnormal_release_rate) as sn_abnormal_release_rate,
            sum(nr_terminal_sn_handover_success_rate) as nr_terminal_sn_handover_success_rate,
            sum(cell_rlc_user_down_loss_package_rate) as cell_rlc_user_down_loss_package_rate,
            sum(rlc_nr_up_business_byte_count) as rlc_nr_up_business_byte_count,
            sum(rlc_nr_down_business_byte_count) as rlc_nr_down_business_byte_count
         FROM cell_15_nsa_eutran_indicator ce INNER JOIN dim_cfg_manual_subscene_cell_lte lte  on ce.cgi = lte.cgi
         GROUP BY lte.scene,lte.subscene;
    END;

