create
    definer = root@localhost procedure sp_cell_15_nsa_cu_indicator(IN quarter_now datetime)
BEGIN
DECLARE tmp_sql TEXT;
DECLARE table_name VARCHAR ( 64 ) DEFAULT concat( 'pm_nsa_nrcellcu_p', date_format( quarter_now, '%Y%m%d%H' ) );


SET tmp_sql = concat('
REPLACE INTO cell_15_nsa_cu_indicator
SELECT
    ''',quarter_now,''',
    cgi,
    pdcp_upoctul/1000             pdcp_up_business_byte_count,
    pdcp_upoctdl/1000             pdcp_down_business_byte_count
FROM ', table_name, ' tb
JOIN dim_cfg_dn_cgi_nsa_cu dim ON tb.object_rdn = dim.dn
WHERE starttime = ''',quarter_now,''';');

CALL sp_exec_sql ( tmp_sql );

END;

