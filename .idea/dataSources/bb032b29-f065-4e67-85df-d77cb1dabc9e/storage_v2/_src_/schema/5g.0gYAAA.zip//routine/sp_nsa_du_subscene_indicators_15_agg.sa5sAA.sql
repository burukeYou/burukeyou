create
    definer = root@`%` procedure sp_nsa_du_subscene_indicators_15_agg(IN quarter_now datetime)
BEGIN
         drop table IF EXISTS nsa_du_subscene_indicators_15;
         create table nsa_du_subscene_indicators_15 as 
         SELECT  quarter_now as starttime,nr.scene_name,nr.subscene_name,
            sum(cell_rlc_down_loss_package_rate) as cell_rlc_down_loss_package_rate,
            sum(mac_up_bler) as mac_up_bler,
            sum(mac_down_bler) as mac_down_bler,
            sum(up_harq_retran_rate) as up_harq_retran_rate,
            sum(down_harq_retran_rate) as down_harq_retran_rate,
            sum(down_rank2_percent) as down_rank2_percent,
            sum(down_rank3_percent) as down_rank3_percent,
            sum(down_rank4_percent) as down_rank4_percent,
            sum(up_qpsk_encoding_percent) as up_qpsk_encoding_percent,
            sum(up_16qam_encoding_percent) as up_16qam_encoding_percent,
            sum(up_64qam_encoding_percent) as up_64qam_encoding_percent,
            sum(up_256qam_encoding_percent) as up_256qam_encoding_percent,
            sum(down_qpsk_encoding_percent) as down_qpsk_encoding_percent,
            sum(down_16qam_encoding_percent) as down_16qam_encoding_percent,
            sum(down_64qam_encoding_percent) as down_64qam_encoding_percent,
            sum(down_256qam_encoding_percent) as down_256qam_encoding_percent,
            sum(rlc_up_business_byte_count) as rlc_up_business_byte_count,
            sum(rlc_down_business_byte_count) as rlc_down_business_byte_count,
            sum(up_business_prb_utilization) as up_business_prb_utilization,
            sum(down_business_prb_utilization) as down_business_prb_utilization,
            sum(up_prb_avg_utilization) as up_prb_avg_utilization,
            sum(down_prb_avg_utilization) as down_prb_avg_utilization,
            sum(pdcch_channel_cce_utilization) as pdcch_channel_cce_utilization,
            sum(up_per_prb_avg_flow) as up_per_prb_avg_flow,
            sum(down_per_prb_avg_flow) as down_per_prb_avg_flow
         FROM cell_15_nsa_du_indicator ce INNER JOIN dim_cfg_manual_subscene_cell_nr nr  on ce.cgi = nr.cgi
         GROUP BY nr.scene_name,nr.subscene_name;
    END;

