create
    definer = root@localhost procedure NewProc()
BEGIN


	declare hour_now datetime;
  declare current datetime default now();
  
   -- app69生产库未设置时区，所以临时将now()函数加8小时，广马保障之后再修改app69数据库配置
  SET current = current +  INTERVAL 8 HOUR;
  
  SET hour_now = (current - INTERVAL (TIME_TO_SEC(current) MOD 3600) SECOND);

	SELECT current;

	
END;

