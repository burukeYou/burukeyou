create
    definer = root@localhost procedure sp_all_indicator_60(IN dt_hour datetime)
begin

call sp_mid_hour_nsa_eutran_agg(dt_hour);
call sp_mid_hour_nsa_cu_agg(dt_hour);
call sp_mid_hour_nsa_du_agg(dt_hour);

call sp_mid_hour_sa_cu_agg(dt_hour);
call sp_mid_hour_sa_du_agg(dt_hour);


call sp_cell_60_nsa_eutran_indicator(dt_hour,'mid_hour_nsa_eutran_agg_tmp');
call sp_cell_60_nsa_cu_indicator(dt_hour,'mid_hour_nsa_cu_agg_tmp');
call sp_cell_60_nsa_du_indicator(dt_hour,'mid_hour_nsa_du_agg_tmp');

call sp_cell_60_sa_cu_indicator(dt_hour);
call sp_cell_60_sa_du_indicator(dt_hour);

end;

