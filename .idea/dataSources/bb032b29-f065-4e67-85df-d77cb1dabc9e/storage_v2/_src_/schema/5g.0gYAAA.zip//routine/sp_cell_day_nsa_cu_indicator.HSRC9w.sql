create
    definer = root@localhost procedure sp_cell_day_nsa_cu_indicator(IN dt_day datetime)
BEGIN
DECLARE tmp_sql TEXT;


SET tmp_sql = concat('
REPLACE INTO cell_day_nsa_cu_indicator
SELECT
''',dt_day,''' starttime,
cgi,
pdcp_upoctul/1000 pdcp_up_business_byte_count,
pdcp_upoctdl/1000 pdcp_down_business_byte_count
FROM  mid_day_nsa_cu_agg_tmp');

CALL sp_exec_sql ( tmp_sql );

END;

