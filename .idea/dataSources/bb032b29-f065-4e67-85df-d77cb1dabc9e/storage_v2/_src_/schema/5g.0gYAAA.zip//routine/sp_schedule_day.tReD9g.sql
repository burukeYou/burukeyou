create
    definer = root@localhost procedure sp_schedule_day()
begin
  declare dt datetime;
  declare current datetime default now();

  SET dt = (current - INTERVAL (TIME_TO_SEC(current) MOD 86400) SECOND) - interval 24 hour;
  select dt;
  call sp_all_indicator_day(dt);

end;

