create
    definer = root@localhost procedure sp_mid_hour_sa_cu_agg(IN dt_hour datetime)
BEGIN
DECLARE tmp_sql TEXT;
DECLARE table_name VARCHAR ( 64 ) DEFAULT concat( 'pm_sa_nrcellcu_p', date_format( dt_hour, '%Y%m%d%H' ) );
TRUNCATE mid_hour_sa_cu_agg_tmp;

SET tmp_sql = concat('
REPLACE INTO mid_hour_sa_cu_agg_tmp SELECT
    ''', dt_hour ,''' ,
    cgi ,
    dn_agg.object_rdn,
    ftpid ,
    version ,
    sum(rru_cellunavailabletime)                   rru_cellunavailabletime,
    sum(pdcp_nbrpktul)                             pdcp_nbrpktul,
    sum(pdcp_nbrpktlossul)                         pdcp_nbrpktlossul,
    sum(pdcp_nbrpktdl)                             pdcp_nbrpktdl,
    sum(pdcp_uppktdiscarddl)                       pdcp_uppktdiscarddl,
    sum(pdcp_upoctul)                              pdcp_upoctul,
    sum(pdcp_upoctdl)                              pdcp_upoctdl,
    sum(drb_nbrmeanestab)                          drb_nbrmeanestab,
    sum(drb_nbrmaxestab)                           drb_nbrmaxestab,
    sum(drb_nbrleft)                               drb_nbrleft,
    sum(rrc_attconnestab)                          rrc_attconnestab,
    sum(rrc_succconnestab)                         rrc_succconnestab,
    sum(rrc_attconnreestab)                        rrc_attconnreestab,
    sum(rrc_succconnreestab)                       rrc_succconnreestab,
    sum(rrc_succconnreestab_nonsrccell)            rrc_succconnreestab_nonsrccell,
    sum(rrc_connmean)                              rrc_connmean,
    sum(rrc_connmax)                               rrc_connmax,
    sum(pdusession_nbrattestab)                    pdusession_nbrattestab,
    sum(pdusession_nbrsuccestab)                   pdusession_nbrsuccestab,
    sum(pdusession_nbrreqrelgnb)                   pdusession_nbrreqrelgnb,
    sum(pdusession_nbrreqrelamfinitnoho)           pdusession_nbrreqrelamfinitnoho,
    sum(pdusession_nbrmeanestab)                   pdusession_nbrmeanestab,
    sum(pdusession_nbrmaxestab)                    pdusession_nbrmaxestab,
    sum(flow_nbrattestab)                          flow_nbrattestab,
    sum(flow_nbrsuccestab)                         flow_nbrsuccestab,
    sum(flow_nbrfailestab)                         flow_nbrfailestab,
    sum(flow_nbrfailestab_causetransport)          flow_nbrfailestab_causetransport,
    sum(flow_nbrfailestab_causeradioresourcesnotavailable)   flow_nbrfailestab_causeradioresourcesnotavailable,
    sum(flow_nbrfailestab_causefailureinradiointerfaceprocedure)   flow_nbrfailestab_causefailureinradiointerfaceprocedure,
    sum(flow_nbrattmod)                            flow_nbrattmod,
    sum(flow_nbrsuccmod)                           flow_nbrsuccmod,
    sum(flow_nbrfailmod)                           flow_nbrfailmod,
    sum(flow_nbrreqrelgnb)                         flow_nbrreqrelgnb,
    sum(flow_nbrreqrelgnb_causeuserinactivity)     flow_nbrreqrelgnb_causeuserinactivity,
    sum(flow_nbrreqrelgnb_normal)                  flow_nbrreqrelgnb_normal,
    sum(flow_nbrreqrelamfinitnoho)                 flow_nbrreqrelamfinitnoho,
    sum(flow_nbrreqrelgnbbyho)                     flow_nbrreqrelgnbbyho,
    sum(flow_nbrmaxestab)                          flow_nbrmaxestab,
    sum(flow_nbrmeanestab)                         flow_nbrmeanestab,
    sum(flow_nbrleft)                              flow_nbrleft,
    sum(flow_nbrhoinc)                             flow_nbrhoinc,
    sum(flow_hoadmitfail)                          flow_hoadmitfail,
    sum(context_attinitalsetup)                    context_attinitalsetup,
    sum(context_succinitalsetup)                   context_succinitalsetup,
    sum(context_failinitalsetup)                   context_failinitalsetup,
    sum(context_attmod)                            context_attmod,
    sum(context_succmod)                           context_succmod ,
    sum(context_failmod)                           context_failmod ,
    sum(context_attrelgnb)                         context_attrelgnb ,
    sum(context_attrelgnb_causeuserinactivity)     context_attrelgnb_causeuserinactivity,
    sum(context_attrelgnb_normal)                  context_attrelgnb_normal,
    sum(context_attrelngc)                         context_attrelngc,
    sum(context_nbrleft)                           context_nbrleft,
    sum(ho_attoutintercung)                        ho_attoutintercung,
    sum(ho_succoutprepintercung)                   ho_succoutprepintercung,
    sum(ho_attoutexecintercung)                    ho_attoutexecintercung,
    sum(ho_succoutintercung)                       ho_succoutintercung,
    sum(ho_avgtimeintercung)                       ho_avgtimeintercung,
    sum(ho_canceloutintercung)                     ho_canceloutintercung,
    sum(ho_attoutintercuxn)                        ho_attoutintercuxn,
    sum(ho_succoutprepintercuxn)                   ho_succoutprepintercuxn,
    sum(ho_attoutexecintercuxn)                    ho_attoutexecintercuxn,
    sum(ho_succoutintercuxn)                       ho_succoutintercuxn,
    sum(ho_avgtimeintercuxn)                       ho_avgtimeintercuxn,
    sum(ho_canceloutintercuxn)                     ho_canceloutintercuxn,
    sum(ho_attoutintracuinterdu)                   ho_attoutintracuinterdu,
    sum(ho_succoutintracuinterdu)                  ho_succoutintracuinterdu,
    sum(ho_attoutcuintradu)                        ho_attoutcuintradu,
    sum(ho_succoutintradu)                         ho_succoutintradu,
    sum(ho_attoutexecintrafreq)                    ho_attoutexecintrafreq,
    sum(ho_succoutintrafreq)                       ho_succoutintrafreq,
    sum(ho_attoutexecinterfreq)                    ho_attoutexecinterfreq,
    sum(ho_succoutinterfreq)                       ho_succoutinterfreq,
    sum(ho_failout)                                ho_failout,
    sum(ho_attprepinc)                             ho_attprepinc,
    sum(ho_succprepinc)                            ho_succprepinc,
    sum(ho_failprepinc)                            ho_failprepinc,
    sum(ho_succexecinc)                            ho_succexecinc,
    sum(iratho_attouteutran)                       iratho_attouteutran ,
    sum(iratho_succprepouteutran)                  iratho_succprepouteutran,
    sum(iratho_failprepouteutran)                  iratho_failprepouteutran,
    sum(iratho_succouteutran)                      iratho_succouteutran,
    sum(iratho_avgtimeouteutran)                   iratho_avgtimeouteutran,
    sum(iratho_avgtimeouteutran_exec)              iratho_avgtimeouteutran_exec,
    sum(pag_pagreceived_ng)                        pag_pagreceived_ng,
    sum(ngsig_connestabatt)                        ngsig_connestabatt,
    sum(ngsig_connestabsucc)                       ngsig_connestabsucc
    FROM   ', table_name, ' dn_agg
    JOIN dim_cfg_dn_cgi_sa_cu dim ON dn_agg.object_rdn = dim.dn
    group by object_rdn;
');


IF
( f_table_exists ( table_name ) ) THEN
    CALL sp_exec_sql ( tmp_sql );

    REPLACE INTO mid_hour_sa_cu_agg
    SELECT *
    FROM mid_hour_sa_cu_agg_tmp;
END IF;

END;

