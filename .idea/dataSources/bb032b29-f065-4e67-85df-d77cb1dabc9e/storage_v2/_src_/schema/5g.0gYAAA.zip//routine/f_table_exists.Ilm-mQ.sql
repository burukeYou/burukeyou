create
    definer = root@localhost function f_table_exists(t_name varchar(128)) returns bit
begin
  declare table_count integer default 0;
  SELECT count(1) into table_count FROM information_schema.TABLES WHERE table_name = t_name;
  return table_count > 0;
end;

