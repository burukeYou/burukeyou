create
    definer = root@localhost procedure sp_mid_day_nsa_cu_agg(IN dt_day datetime)
BEGIN
DECLARE tmp_sql TEXT;

TRUNCATE mid_day_nsa_cu_agg_tmp;

SET tmp_sql = concat('
REPLACE INTO mid_day_nsa_cu_agg_tmp
SELECT
''',dt_day,''' starttime,
cgi,
ftpid,
version,
sum(rru_cellunavailabletime) rru_cellunavailabletime,
sum(pdcp_nbrpktul) pdcp_nbrpktul,
sum(pdcp_nbrpktlossul) pdcp_nbrpktlossul,
sum(pdcp_nbrpktdl) pdcp_nbrpktdl,
sum(pdcp_uppktdiscarddl) pdcp_uppktdiscarddl,
sum(pdcp_upoctul) pdcp_upoctul,
sum(pdcp_upoctdl) pdcp_upoctdl,
sum(pdcp_upoctul_splitfromlte) pdcp_upoctul_splitfromlte,
sum(pdcp_upoctdl_splittolte) pdcp_upoctdl_splittolte,
sum(drb_nbrmeanestab) drb_nbrmeanestab,
sum(drb_nbrmaxestab) drb_nbrmaxestab,
sum(drb_nbrleft) drb_nbrleft
FROM mid_hour_nsa_cu_agg where starttime between ''', dt_day ,''' and ''', dt_day ,''' + interval 23 hour
GROUP BY cgi ;');

CALL sp_exec_sql(tmp_sql);

END;

