create
    definer = root@localhost procedure sp_cell_day_sa_cu_indicator(IN dt_day datetime)
BEGIN
DECLARE tmp_sql TEXT;

SET tmp_sql = concat('
REPLACE INTO cell_day_sa_cu_indicator
SELECT
''',dt_day,''' starttime,
cgi cgi,
 -- ------eu01 cu-----
rrc_succconnestab/rrc_attconnestab               rrc_connect_success_rate ,
flow_nbrsuccestab/flow_nbrattestab               qos_flow_establish_success_rate ,
ngsig_connestabsucc/ngsig_connestabatt           ngsig_establish_success_rate ,
(rrc_succconnestab/rrc_attconnestab)*(flow_nbrsuccestab/flow_nbrattestab)*(ngsig_connestabsucc/ngsig_connestabatt) radio_connect_rate ,
 -- ------eu02 cu-----
(context_attrelgnb-context_attrelgnb_normal)/(context_succinitalsetup+context_nbrleft+ho_succexecinc+ rrc_succconnreestab_nonsrccell) radio_drop_rate ,
(flow_nbrreqrelgnb-flow_nbrreqrelgnb_normal+flow_hoadmitfail)/(flow_nbrleft+flow_nbrsuccestab+flow_nbrhoinc) flow_drop_rate ,
 rrc_attconnreestab/(rrc_attconnreestab+rrc_attconnestab) rrc_connect_reestablish_rate ,
 -- -------eu03 cu-----
 ho_succoutintercung/ho_attoutintercung          gNB_inter_NG_handover_success_rate ,
 ho_succoutintercuxn/ho_attoutintercuxn          gNB_inter_Xn_handover_success_rate ,
 (ho_succoutintercung+ho_succoutintercuxn)/(ho_attoutintercung+ho_attoutintercuxn) gNB_inter_handover_success_rate,
 (ho_succoutintracuinterdu+ho_succoutintradu)/(ho_attoutintracuinterdu+ho_attoutcuintradu) gNB_intra_handover_success_rate ,
 (ho_succoutintercung+ho_succoutintercuxn+ho_succoutintracuinterdu+ho_succoutintradu)/(ho_attoutintercung+ho_attoutintercuxn+ho_attoutintracuinterdu+ho_attoutcuintradu) handover_success_rate ,
 ho_succoutintrafreq/ho_attoutexecintrafreq      intra_frequency_handover_success_rate ,
 ho_succoutinterfreq/ho_attoutexecinterfreq      inter_frequency_handover_success_rate ,
   -- ------eu05 cu-----
 pdcp_upoctul/1000                               pdcp_up_business_byte_count ,
 pdcp_upoctdl/1000                               pdcp_down_business_byte_count
FROM mid_day_sa_cu_agg_tmp ;');

CALL sp_exec_sql ( tmp_sql );

END;

