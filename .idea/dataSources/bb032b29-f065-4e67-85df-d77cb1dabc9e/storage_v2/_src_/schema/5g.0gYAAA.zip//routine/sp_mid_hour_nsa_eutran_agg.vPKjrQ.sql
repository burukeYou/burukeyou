create
    definer = root@localhost procedure sp_mid_hour_nsa_eutran_agg(IN dt_hour datetime)
BEGIN
DECLARE tmp_sql TEXT;
DECLARE table_name VARCHAR ( 64 ) DEFAULT concat( 'pm_nsa_eutrancell_p', date_format( dt_hour, '%Y%m%d%H' ) );

TRUNCATE mid_hour_nsa_eutran_agg_tmp;


SET tmp_sql = concat('
REPLACE INTO mid_hour_nsa_eutran_agg_tmp
SELECT
''',dt_hour,''' starttime,
cgi,
ftpid,
version,
sum(rrc_connmean_nr) rrc_connmean_nr,
sum(rrc_connmax_nr) rrc_connmax_nr,
sum(rrc_connmean_dc) rrc_connmean_dc,
sum(rrc_connmax_dc) rrc_connmax_dc,
sum(erab_nbrmeanestab_scgsplit) erab_nbrmeanestab_scgsplit,
sum(erab_nbrmaxestab_scgsplit) erab_nbrmaxestab_scgsplit,
sum(ho_attoutinterenb_withsn) ho_attoutinterenb_withsn,
sum(ho_succoutprepinterenb_withsn) ho_succoutprepinterenb_withsn,
sum(ho_attoutexecinterenb_withsn) ho_attoutexecinterenb_withsn,
sum(ho_succoutinterenb_withsn) ho_succoutinterenb_withsn,
sum(rlc_upoctul) rlc_upoctul,
sum(rlc_upoctdl) rlc_upoctdl,
sum(rlc_nbrsendpktdl) rlc_nbrsendpktdl,
sum(rlc_nbrpktlossdl) rlc_nbrpktlossdl,
sum(dc_snaddtimemean) dc_snaddtimemean,
sum(dc_snaddtimemax) dc_snaddtimemax,
sum(dc_nbrattsnadd) dc_nbrattsnadd,
sum(dc_nbrsuccsnadd) dc_nbrsuccsnadd,
sum(dc_nbrfailsnadd) dc_nbrfailsnadd,
sum(dc_nbrattsnmod_mninitiated) dc_nbrattsnmod_mninitiated,
sum(dc_nbrsuccsnmod_mninitiated) dc_nbrsuccsnmod_mninitiated,
sum(dc_nbrreqsnrelbymn) dc_nbrreqsnrelbymn,
sum(dc_nbrreqsnrelbymn_normal) dc_nbrreqsnrelbymn_normal,
sum(dc_nbrreqsnrelbysn) dc_nbrreqsnrelbysn,
sum(dc_nbrreqsnrelbysn_normal) dc_nbrreqsnrelbysn_normal,
sum(dc_nbrattsnchange_sninitiated) dc_nbrattsnchange_sninitiated,
sum(dc_nbrpreparesuccsnchange_sninitiated) dc_nbrpreparesuccsnchange_sninitiated,
sum(dc_nbrsuccsnchange_sninitiated) dc_nbrsuccsnchange_sninitiated 
FROM ',table_name,' tb
join  dim_cfg_dn_cgi dim ON tb.object_rdn = dim.dn
GROUP BY tb.object_rdn');

  IF (f_table_exists(table_name)) THEN
    CALL sp_exec_sql(tmp_sql);

    REPLACE INTO mid_hour_nsa_eutran_agg
    SELECT *
    FROM mid_hour_nsa_eutran_agg_tmp;
  END IF;

END;

