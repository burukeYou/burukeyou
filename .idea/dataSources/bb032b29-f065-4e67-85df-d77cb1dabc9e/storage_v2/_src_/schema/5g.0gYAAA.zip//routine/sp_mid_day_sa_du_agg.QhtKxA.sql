create
    definer = root@localhost procedure sp_mid_day_sa_du_agg(IN dt_day datetime)
BEGIN
DECLARE tmp_sql TEXT;

TRUNCATE mid_day_sa_du_agg_tmp;

SET tmp_sql = concat('
REPLACE INTO mid_day_sa_du_agg_tmp SELECT
    ''', dt_day ,''' ,
    cgi ,
    object_rdn,
    ftpid ,
    version ,
    sum(rlc_nbrpktlossdl)                    rlc_nbrpktlossdl,
    sum(rlc_nbrpktdl)                        rlc_nbrpktdl  ,
    sum(mac_nbrreserrtbul)                   mac_nbrreserrtbul ,
    sum(mac_nbrinittbul)                     mac_nbrinittbul ,
    sum(mac_nbrreserrtbdl)                   mac_nbrreserrtbdl ,
    sum(mac_nbrinittbdl)                     mac_nbrinittbdl ,
    sum(mac_nbrtbul)                         mac_nbrtbul ,
    sum(mac_nbrtbdl)                         mac_nbrtbdl ,
    sum(mac_nbrtbdl_rank2)                   mac_nbrtbdl_rank2 ,
    sum(mac_nbrtbdl_rank3)                   mac_nbrtbdl_rank3 ,
    sum(mac_nbrtbdl_rank4)                   mac_nbrtbdl_rank4 ,
    sum(mac_nbrinittbul_qpsk)                mac_nbrinittbul_qpsk ,
    sum(mac_nbrinittbul_16qam)               mac_nbrinittbul_16qam ,
    sum(mac_nbrinittbul_64qam)               mac_nbrinittbul_64qam ,
    sum(mac_nbrinittbul_256qam)              mac_nbrinittbul_256qam ,
    sum(mac_nbrinittbdl_qpsk)                mac_nbrinittbdl_qpsk ,
    sum(mac_nbrinittbdl_16qam)               mac_nbrinittbdl_16qam  ,
    sum(mac_nbrinittbdl_64qam)               mac_nbrinittbdl_64qam  ,
    sum(mac_nbrinittbdl_256qam)              mac_nbrinittbdl_256qam ,
    sum(rlc_upoctul)                         rlc_upoctul ,
    sum(rlc_upoctdl)                         rlc_upoctdl  ,
    sum(rru_dtchprbassnul)                   rru_dtchprbassnul ,
    sum(rru_puschprbtot)                     rru_puschprbtot ,
    sum(rru_dtchprbassndl)                   rru_dtchprbassndl ,
    sum(rru_pdschprbtot)                     rru_pdschprbtot ,
    sum(rru_puschprbassn)                    rru_puschprbassn ,
    sum(rru_pdschprbassn)                    rru_pdschprbassn ,
    sum(rru_pdcchcceutil)                    rru_pdcchcceutil ,
    sum(rru_pdcchcceavail)                   rru_pdcchcceavail ,
    sum(mac_cpoctul)                         mac_cpoctul ,
    sum(mac_cpoctdl)                         mac_cpoctdl
    FROM   mid_hour_sa_du_agg where starttime between ''', dt_day, ''' and ''', dt_day, ''' + interval 23 hour
    group by cgi;
');

CALL sp_exec_sql ( tmp_sql );

END;

