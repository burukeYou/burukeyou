create
    definer = root@localhost procedure sp_mid_hour_nsa_cu_agg(IN dt_hour datetime)
BEGIN
DECLARE tmp_sql TEXT;
DECLARE table_name VARCHAR ( 64 ) DEFAULT concat( 'pm_nsa_nrcellcu_p', date_format( dt_hour, '%Y%m%d%H' ) );

TRUNCATE mid_hour_nsa_cu_agg_tmp;

SET tmp_sql = concat('
REPLACE INTO mid_hour_nsa_cu_agg_tmp
SELECT
''',dt_hour,''' starttime,
cgi,
ftpid,
version,
sum(rru_cellunavailabletime) rru_cellunavailabletime,
sum(pdcp_nbrpktul) pdcp_nbrpktul,
sum(pdcp_nbrpktlossul) pdcp_nbrpktlossul,
sum(pdcp_nbrpktdl) pdcp_nbrpktdl,
sum(pdcp_uppktdiscarddl) pdcp_uppktdiscarddl,
sum(pdcp_upoctul) pdcp_upoctul,
sum(pdcp_upoctdl) pdcp_upoctdl,
sum(pdcp_upoctul_splitfromlte) pdcp_upoctul_splitfromlte,
sum(pdcp_upoctdl_splittolte) pdcp_upoctdl_splittolte,
sum(drb_nbrmeanestab) drb_nbrmeanestab,
sum(drb_nbrmaxestab) drb_nbrmaxestab,
sum(drb_nbrleft) drb_nbrleft
FROM ',table_name,' dn_agg
JOIN dim_cfg_dn_cgi_nsa_cu dim ON dim.dn = dn_agg.object_rdn
GROUP BY object_rdn ;');

  IF (f_table_exists(table_name)) THEN
    CALL sp_exec_sql(tmp_sql);

    REPLACE INTO mid_hour_nsa_cu_agg
    SELECT *
    FROM mid_hour_nsa_cu_agg_tmp;
  END IF;

END;

