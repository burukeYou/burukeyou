create
    definer = root@localhost procedure sp_schedule_hour()
begin
  declare hour_now datetime;
  
  declare current datetime default now() + INTERVAL 8 HOUR;

  SET hour_now = (current - INTERVAL (TIME_TO_SEC(current) MOD 3600) SECOND);

  call sp_all_indicator_60(hour_now);

  call sp_all_indicator_60(hour_now - interval 1 hour);

  call sp_all_indicator_60(hour_now - interval 2 hour);

  call sp_all_indicator_60(hour_now - interval 3 hour);

end;

