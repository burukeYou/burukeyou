create
    definer = root@localhost procedure sp_all_indicator_day(IN dt_day datetime)
begin

call sp_mid_day_nsa_eutran_agg(dt_day);
call sp_mid_day_nsa_cu_agg(dt_day);
call sp_mid_day_nsa_du_agg(dt_day);

call sp_mid_day_sa_cu_agg(dt_day);
call sp_mid_day_sa_du_agg(dt_day);


call sp_cell_day_nsa_eutran_indicator(dt_day);
call sp_cell_day_nsa_cu_indicator(dt_day);
call sp_cell_day_nsa_du_indicator(dt_day);

call sp_cell_day_sa_cu_indicator(dt_day);
call sp_cell_day_sa_du_indicator(dt_day);

end;

