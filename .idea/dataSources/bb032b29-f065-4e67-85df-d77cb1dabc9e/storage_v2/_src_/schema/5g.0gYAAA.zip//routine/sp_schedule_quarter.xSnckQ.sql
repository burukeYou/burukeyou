create
    definer = root@localhost procedure sp_schedule_quarter()
begin
  declare quarter_now datetime;
  declare current datetime default now();

  SET quarter_now =(current - INTERVAL (TIME_TO_SEC(current) MOD 900) SECOND);

  call sp_all_indicator_15(quarter_now - interval 30 minute);

  call sp_all_indicator_15(quarter_now - interval 45 minute);

  call sp_all_indicator_15(quarter_now - interval 60 minute);

  call sp_all_indicator_15(quarter_now - interval 75 minute);

  call sp_all_indicator_15(quarter_now - interval 90 minute);

  call sp_all_indicator_15(quarter_now - interval 105 minute);

  call sp_all_indicator_15(quarter_now - interval 120 minute);

end;

