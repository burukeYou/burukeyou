create
    definer = root@localhost procedure sp_cell_60_nsa_eutran_indicator(IN dt_hour datetime, IN table_name varchar(64))
BEGIN
DECLARE tmp_sql TEXT;


SET tmp_sql = concat('
REPLACE INTO cell_60_nsa_eutran_indicator
SELECT
''',dt_hour,''' starttime,
cgi,
-- -------------NSA_EUTRAN eu01-----
dc_nbrsuccsnadd/dc_nbrattsnadd sn_add_success_rate,
(dc_nbrreqsnrelbymn + dc_nbrreqsnrelbysn - dc_nbrreqsnrelbymn_normal - dc_nbrreqsnrelbysn_normal)/(dc_nbrreqsnrelbymn + dc_nbrreqsnrelbysn) sn_abnormal_release_rate,
ho_attoutinterenb_withsn/ho_succoutinterenb_withsn nr_terminal_sn_handover_success_rate,
-- -------------NSA_EUTRAN eu04-----
rlc_nbrpktlossdl/rlc_nbrsendpktdl cell_rlc_user_down_loss_package_rate,
-- -------------NSA_EUTRAN eu05-----
rlc_upoctul/1000 rlc_nr_up_business_byte_count,
rlc_upoctdl/1000 rlc_nr_down_business_byte_count
FROM ',table_name);

CALL sp_exec_sql ( tmp_sql );

END;

