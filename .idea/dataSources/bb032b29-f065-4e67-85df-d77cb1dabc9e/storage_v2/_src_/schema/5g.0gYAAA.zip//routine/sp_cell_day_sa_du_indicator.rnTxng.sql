create
    definer = root@localhost procedure sp_cell_day_sa_du_indicator(IN dt_day datetime)
BEGIN
DECLARE tmp_sql TEXT;

SET tmp_sql = concat('
REPLACE INTO cell_day_sa_du_indicator
SELECT
    ''',dt_day,''' starttime,
     cgi cgi,
     -- ------eu04 du-----
     rlc_nbrpktlossdl/rlc_nbrpktdl                    cell_rlc_down_loss_package_rate ,
     mac_nbrreserrtbul/mac_nbrinittbul                mac_up_bler ,
     mac_nbrreserrtbdl/mac_nbrinittbdl                mac_down_bler ,
     (mac_nbrtbul-mac_nbrinittbul)/mac_nbrtbul        up_harq_retran_rate ,
     (mac_nbrtbdl-mac_nbrinittbdl)/mac_nbrtbdl        down_harq_retran_rate ,
     mac_nbrtbdl_rank2/mac_nbrtbdl                    down_rank2_percent ,
     mac_nbrtbdl_rank3/mac_nbrtbdl                    down_rank3_percent ,
     mac_nbrtbdl_rank4/mac_nbrtbdl                    down_rank4_percent ,
     mac_nbrinittbul_qpsk/mac_nbrinittbul             up_qpsk_encoding_percent ,
     mac_nbrinittbul_16qam/mac_nbrinittbul            up_16qam_encoding_percent ,
     mac_nbrinittbul_64qam/mac_nbrinittbul            up_64qam_encoding_percent ,
     mac_nbrinittbul_256qam/mac_nbrinittbul           up_256qam_encoding_percent ,
     mac_nbrinittbdl_qpsk/mac_nbrinittbdl             down_qpsk_encoding_percent ,
     mac_nbrinittbdl_16qam/mac_nbrinittbdl            down_16qam_encoding_percent ,
     mac_nbrinittbdl_64qam/mac_nbrinittbdl            down_64qam_encoding_percent ,
     mac_nbrinittbdl_256qam/mac_nbrinittbdl           down_256qam_encoding_percent ,
     -- ------eu05 du-----
     rlc_upoctul/1000                                 rlc_up_business_byte_count ,
     rlc_upoctdl/1000                                 rlc_down_business_byte_count ,
     rru_dtchprbassnul/rru_puschprbtot                up_business_prb_utilization ,
     rru_dtchprbassndl/rru_pdschprbtot                down_business_prb_utilization ,
     rru_puschprbassn/rru_puschprbtot                 up_prb_avg_utilization ,
     rru_pdschprbassn/rru_pdschprbtot                 down_prb_avg_utilization ,
     rru_pdcchcceutil/rru_pdcchcceavail               pdcch_channel_cce_utilization ,
     mac_cpoctul*8/rru_dtchprbassnul                  up_per_prb_avg_flow ,
     mac_cpoctdl*8/rru_dtchprbassndl                  down_per_prb_avg_flow
FROM mid_day_sa_du_agg_tmp ;');

CALL sp_exec_sql ( tmp_sql );

END;

