create
    definer = root@localhost procedure sp_all_indicator_15(IN quarter_now datetime)
begin
call sp_cell_15_nsa_eutran_indicator(quarter_now);
call sp_cell_15_nsa_du_indicator(quarter_now);
call sp_cell_15_nsa_cu_indicator(quarter_now);
call sp_cell_15_sa_du_indicator(quarter_now);
call sp_cell_15_sa_cu_indicator(quarter_now);
end;

